<?php

namespace LegendDevelopment\Theme\Support;

use Throwable;

/**
 * Which language this plugin speaks to each person, and which of them are on.
 *
 * Most of this was already there and it is worth saying what, because the part
 * that had to be written is small and the part that did not is the reason it
 * works at all. Pelican stores a language on every user and its
 * LanguageMiddleware calls setLocale() with it on every request, so
 * app()->getLocale() is already the reader's own choice rather than the
 * server's. Laravel's translator already falls back to the fallback locale per
 * missing key rather than per missing file, so a half-translated language is a
 * working language: what has been translated appears, and the rest is English.
 *
 * That last property is why this is built around partial translations rather
 * than treating them as a defect. A plugin with seven hundred strings is never
 * finished in every language at once, and a design that only worked at a
 * hundred per cent would mean shipping nothing until then.
 *
 * So what is added here is the switch. A language being present is not the same
 * as it being wanted: somebody running an English-speaking team on a panel where
 * one person's account is set to German does not necessarily want half of one
 * page in German. Turning a language off sends those readers back to English for
 * this plugin's strings and leaves the rest of the panel alone.
 */
class Languages
{
    /**
     * The language this plugin is written in.
     *
     * Not the same thing as the one it answers in - see main(). This is where
     * Laravel's own per-key fallback lands, so a string missing from every other
     * language ends up here, and it is what completeness is measured against
     * because it is the only one complete by definition.
     */
    public const BASE = 'en';

    private static ?string $main = null;

    /** @var array<string, string>|null */
    private static ?array $labels = null;

    /**
     * The languages Pelican itself ships, and only those.
     *
     * Matched against its lang/ directory rather than written from memory, and
     * that is not pedantry - the first version of this list had `zh`, which is
     * not a locale this panel can ever be set to. Pelican has `zh_CN` and
     * `zh_TW`, so a Chinese reader would have been skipped entirely by a list
     * that looked complete. `sr` was missing outright for the same reason.
     *
     * Names in the language itself rather than in English: somebody looking for
     * their own language scans for the word they would use for it, which is
     * "Nederlands" and not "Dutch". The English name is beside it for whoever is
     * administering the panel and does not read it.
     */
    private const NAMES = [
        'ar' => 'العربية (Arabic)',
        'be' => 'Беларуская (Belarusian)',
        'bg' => 'Български (Bulgarian)',
        'cs' => 'Čeština (Czech)',
        'da' => 'Dansk (Danish)',
        'de' => 'Deutsch (German)',
        'el' => 'Ελληνικά (Greek)',
        'en' => 'English',
        'es' => 'Español (Spanish)',
        'fi' => 'Suomi (Finnish)',
        'fr' => 'Français (French)',
        'hu' => 'Magyar (Hungarian)',
        'id' => 'Bahasa Indonesia',
        'it' => 'Italiano (Italian)',
        'ja' => '日本語 (Japanese)',
        'ko' => '한국어 (Korean)',
        'lt' => 'Lietuvių (Lithuanian)',
        'nl' => 'Nederlands (Dutch)',
        'no' => 'Norsk (Norwegian)',
        'pl' => 'Polski (Polish)',
        'pt' => 'Português (Portuguese)',
        'pt_BR' => 'Português do Brasil',
        'ro' => 'Română (Romanian)',
        'ru' => 'Русский (Russian)',
        'sk' => 'Slovenčina (Slovak)',
        'sr' => 'Српски (Serbian)',
        'sv' => 'Svenska (Swedish)',
        'tr' => 'Türkçe (Turkish)',
        'uk' => 'Українська (Ukrainian)',
        'vi' => 'Tiếng Việt (Vietnamese)',
        'zh_CN' => '简体中文 (Simplified Chinese)',
        'zh_TW' => '繁體中文 (Traditional Chinese)',
    ];

    /** @var array<string, array<int, string>>|null */
    private static ?array $scanned = null;

    private static ?string $current = null;

    /**
     * Which languages this plugin actually carries, found by looking.
     *
     * A directory under lang/ rather than a list in code: adding a translation
     * should be adding files, and a list would be a second place to remember.
     *
     * @return array<int, string>
     */
    public static function available(): array
    {
        if (self::$scanned !== null) {
            return self::$scanned['codes'];
        }

        $codes = [self::BASE];

        try {
            /*
              * directory() and not id(). plugin_path() takes the plugin's
              * folder name and then path segments, so `id() . '/lang'` handed
              * it "Essentials/lang" as the folder - and the id is capitalised
              * while the folder is not. Between them this globbed a path that
              * does not exist, found nothing, and left the Languages tab empty
              * while looking as though it worked.
              */
             $directory = plugin_path(Theme::directory(), 'lang');

            foreach ((array) glob($directory . '/*', GLOB_ONLYDIR) as $path) {
                $code = basename((string) $path);

                // Only the ones this class can name. An unrecognised directory
                // is more likely a mistake than a language, and a picker with a
                // bare code in it helps nobody.
                if ($code !== self::BASE && array_key_exists($code, self::NAMES)) {
                    $codes[] = $code;
                }
            }
        } catch (Throwable) {
            // Nothing readable, which leaves English - the one that is compiled
            // into every install and cannot be missing.
        }

        /*
         * And whatever somebody has uploaded, which is a language this plugin
         * carries nothing for and can still answer in.
         *
         * Not held to the names list the shipped ones are: that list is Pelican's
         * own locales, and it is there so a stray directory in the package is
         * not offered as a language. An uploaded one was put there deliberately
         * by somebody who typed the code themselves, and refusing it because it
         * is not in a list written here would be this plugin deciding which
         * languages are allowed to exist.
         */
        try {
            foreach (Translations::uploaded() as $code) {
                if ($code !== self::BASE && !in_array($code, $codes, true)) {
                    $codes[] = $code;
                }
            }
        } catch (Throwable) {
            // The shipped ones on their own are still a working list.
        }

        self::$scanned = ['codes' => $codes];

        return $codes;
    }

    /**
     * The picker's options: every language carried, named.
     *
     * @return array<string, string>
     */
    public static function options(): array
    {
        $options = [];

        foreach (self::available() as $code) {
            $options[$code] = self::name($code);
        }

        asort($options);

        return $options;
    }

    /**
     * A language's name, or its code.
     *
     * The code is the honest fallback for an uploaded language: nothing here
     * knows what it is called, and inventing a name would be worse than showing
     * the two letters somebody typed.
     */
    /** Whether this is one of the locales Pelican itself ships. */
    public static function knows(string $code): bool
    {
        return array_key_exists($code, self::NAMES);
    }

    public static function name(string $code): string
    {
        return self::labels()[$code] ?? self::NAMES[$code] ?? $code;
    }

    /**
     * The names an administrator has given, over the ones this plugin knows.
     *
     * Two reasons for it. A language uploaded under a code of somebody's own -
     * Gaming-NL - has no name here and would otherwise be listed as its code,
     * which is a thing to decipher rather than to read. And a panel may want a
     * shipped language called something else: a server community calling Dutch
     * "Gaming-NL" is naming their edit of it, not correcting Nederlands.
     *
     * @return array<string, string>
     */
    public static function labels(): array
    {
        if (self::$labels !== null) {
            return self::$labels;
        }

        $labels = [];

        try {
            foreach (explode('|', (string) Theme::config('language_labels', '')) as $pair) {
                [$code, $label] = array_pad(explode('=', $pair, 2), 2, null);

                $code = is_string($code) ? trim($code) : '';
                $label = is_string($label) ? trim($label) : '';

                if ($code !== '' && $label !== '' && Translations::code($code)) {
                    $labels[$code] = mb_substr($label, 0, 60);
                }
            }
        } catch (Throwable) {
            return self::$labels = [];
        }

        return self::$labels = $labels;
    }

    /**
     * The labels as the repeater's rows, one per language this plugin carries.
     *
     * Every language rather than only the renamed ones, so the form is a list
     * of what exists with a box beside each - which is what somebody opening it
     * expects, rather than an empty repeater they have to guess the codes for.
     *
     * @return array<int, array{code: string, label: string}>
     */
    public static function labelRows(): array
    {
        $labels = self::labels();
        $rows = [];

        foreach (self::available() as $code) {
            $rows[] = ['code' => $code, 'label' => $labels[$code] ?? ''];
        }

        return $rows;
    }

    /**
     * The rows as they are stored.
     *
     * A row with no label of its own is dropped rather than stored empty: the
     * absence is what makes name() fall through to the name this plugin knows,
     * and storing "nl=" would be storing a decision nobody made.
     *
     * @param  array<mixed, mixed>  $rows
     */
    public static function sanitiseLabels(mixed $rows): string
    {
        if (!is_array($rows)) {
            return '';
        }

        $pairs = [];

        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }

            $code = is_string($row['code'] ?? null) ? trim($row['code']) : '';
            $label = is_string($row['label'] ?? null) ? trim($row['label']) : '';

            // The separators this is stored with cannot appear inside a label,
            // or reading it back would split in the wrong place.
            $label = str_replace(['|', '='], ' ', $label);
            $label = trim(preg_replace('/\s+/u', ' ', $label) ?? '');

            if ($code === '' || $label === '' || !Translations::code($code)) {
                continue;
            }

            $pairs[$code] = $code . '=' . mb_substr($label, 0, 60);
        }

        return implode('|', $pairs);
    }

    /**
     * The languages an administrator has switched off.
     *
     * Stored as what is off rather than what is on, for the same reason the
     * feature switches are: a translation added in a later release should
     * arrive working rather than arrive invisible because it was not in a list
     * written before it existed.
     *
     * @return array<int, string>
     */
    public static function disabled(): array
    {
        try {
            $held = Theme::config('languages_off', '');

            if (!is_string($held) || trim($held) === '') {
                return [];
            }

            $off = [];

            foreach (explode(',', $held) as $code) {
                $code = trim($code);

                // English is never off. Everything falls back to it, and a panel
                // that had switched off its own fallback would show keys.
                if ($code !== '' && $code !== self::BASE && array_key_exists($code, self::NAMES)) {
                    $off[] = $code;
                }
            }

            return array_values(array_unique($off));
        } catch (Throwable) {
            return [];
        }
    }

    /**
     * Whether this plugin's answer about language is the panel's answer too.
     *
     * Off, this decides only its own strings and a reader whose language is
     * switched off sees Pelican in their language and these pages in English.
     * On, the decision is made once for everything.
     *
     * A setting rather than simply doing it, because it reaches outside this
     * plugin - it changes the language of pages this plugin did not write, and
     * a plugin that does that without being asked is a plugin nobody can
     * predict.
     */
    public static function leads(): bool
    {
        try {
            return Features::enabled(Features::LANGUAGES)
                && (bool) Theme::config('languages_panel', true);
        } catch (Throwable) {
            return false;
        }
    }

    /**
     * The language to answer in when somebody's own choice cannot be honoured.
     *
     * Chosen rather than assumed. It was English, silently: a reader whose
     * language was switched off got English whether or not anybody on the panel
     * reads English, which on a Dutch team is the wrong answer arrived at
     * confidently.
     *
     * It has to be one this plugin actually carries, or the fallback would be a
     * language nothing is written in - so a setting naming a language that has
     * since been removed comes back as BASE rather than as itself.
     */
    public static function main(): string
    {
        if (self::$main !== null) {
            return self::$main;
        }

        try {
            $chosen = Theme::config('languages_main', self::BASE);

            if (!is_string($chosen) || !in_array($chosen, self::available(), true)) {
                return self::$main = self::BASE;
            }

            return self::$main = $chosen;
        } catch (Throwable) {
            return self::$main = self::BASE;
        }
    }

    /**
     * Whether a language may be answered in.
     *
     * The main language is always yes, whichever it is. Switching off the one
     * everything falls back to would leave nothing to fall back to, and the
     * reader would meet key names.
     */
    public static function enabled(string $code): bool
    {
        return $code === self::main()
            || $code === self::BASE
            || !in_array($code, self::disabled(), true);
    }

    /**
     * What to write the settings form's answer back as.
     *
     * The form offers what is on, so this is inverted on the way in - and it is
     * inverted against what is *available*, not against what was ticked, so
     * unticking everything really does mean everything off rather than nothing
     * changed.
     */
    /**
     * The main language as it is stored.
     *
     * Held to what this plugin carries rather than taken as given: the form
     * offers only those, but a value can also arrive from an imported settings
     * file, and a main language nothing is written in would leave every reader
     * whose own is switched off looking at key names.
     */
    public static function sanitiseMain(mixed $code): string
    {
        return is_string($code) && in_array($code, self::available(), true) ? $code : self::BASE;
    }

    public static function sanitise(mixed $on): string
    {
        $on = is_array($on) ? array_filter($on, 'is_string') : [];

        $off = [];

        foreach (self::available() as $code) {
            // Neither the main language nor the one everything is authored in
            // can be switched off, whatever the form was submitted with.
            if ($code !== self::BASE && $code !== self::main() && !in_array($code, $on, true)) {
                $off[] = $code;
            }
        }

        return implode(',', $off);
    }

    /**
     * The locale this plugin should answer in, for whoever is reading.
     *
     * Pelican has already set the application locale from the user's own
     * account by the time anything here runs, so this is only ever deciding
     * whether to honour it: a language this plugin does not carry, or one an
     * administrator has switched off, comes back as English.
     *
     * Note what this does not do - it does not change the application locale.
     * The rest of the panel goes on speaking whatever the reader chose; only
     * this plugin's own strings are affected, which is what "switch off a
     * language" can honestly mean from inside a plugin.
     */
    public static function current(): string
    {
        /*
         * Held for the request, and that is not a micro-optimisation.
         *
         * Every single Theme::trans() call asks this, and the settings pages
         * draw four hundred strings each - so without it, one page view meant
         * four hundred config reads, four hundred explode() calls and four
         * hundred array_unique() passes to answer a question whose answer
         * cannot change while the request is running. Neither the reader's
         * account nor the panel's settings move mid-request.
         */
        if (self::$current !== null) {
            return self::$current;
        }

        try {
            $locale = (string) app()->getLocale();

            if ($locale === '' || !in_array($locale, self::available(), true)) {
                return self::$current = self::main();
            }

            return self::$current = (self::enabled($locale) ? $locale : self::main());
        } catch (Throwable) {
            return self::$current = self::BASE;
        }
    }

    /**
     * Cleared when the setting is saved, because the settings page goes on to
     * re-render itself in the same request that changed it - and would
     * otherwise re-render in the language it had on the way in.
     */
    public static function forget(): void
    {
        self::$current = null;
        self::$scanned = null;
        self::$main = null;
        self::$labels = null;
    }

    /**
     * How much of a language is actually translated, as a percentage.
     *
     * Shown in the settings list because a partial translation is normal here
     * and hiding that would be the dishonest option: somebody switching on a
     * language that is a third done should be able to see that before their
     * users do, rather than after.
     *
     * Counted against English, which is the only complete one by definition.
     */
    public static function completeness(string $code): int
    {
        if ($code === self::BASE) {
            return 100;
        }

        try {
            $base = self::count(self::BASE);

            if ($base === 0) {
                return 0;
            }

            return (int) min(100, round(self::count($code) / $base * 100));
        } catch (Throwable) {
            return 0;
        }
    }

    /**
     * Every leaf string in a language, counted.
     *
     * The files are included rather than parsed. They are this plugin's own
     * files, they are PHP returning an array, and a parser here would be a
     * second implementation of something the language already does - the build
     * has one for a different reason and does not need company.
     */
    private static function count(string $code): int
    {
        static $counted = [];

        if (array_key_exists($code, $counted)) {
            return $counted[$code];
        }

        $total = 0;

        try {
            /*
             * Both places a translation can live, and counting only the first
             * was wrong.
             *
             * A language that ships with the plugin is in its lang directory. An
             * uploaded one is in the application's override directory, which is
             * where it has to be to survive an update. Counting only the plugin
             * meant every uploaded language showed as 0% translated however
             * complete it was - a number that would have sent somebody looking
             * for a fault in a file that was fine.
             *
             * Keys in both are counted once: an override of a string the plugin
             * already ships is the same string translated, not a second one.
             */
            $seen = [];

            foreach ([
                plugin_path(Theme::directory(), 'lang', $code),
                lang_path('vendor/' . Theme::id() . '/' . $code),
            ] as $directory) {
                foreach ((array) glob($directory . '/*.php') as $file) {
                    $values = @include (string) $file;

                    if (!is_array($values)) {
                        continue;
                    }

                    $group = basename((string) $file, '.php');

                    foreach (self::paths($values) as $key) {
                        $seen[$group . '.' . $key] = true;
                    }
                }
            }

            $total = count($seen);
        } catch (Throwable) {
            $total = 0;
        }

        return $counted[$code] = $total;
    }

    /**
     * Every string in a lang file, as its dotted key.
     *
     * Keys rather than a count, because a language can now be translated in two
     * places at once - what the plugin ships and what somebody uploaded over it
     * - and adding two counts would report a string translated twice as two
     * strings and put a language past a hundred per cent.
     *
     * @param  array<mixed>  $values
     * @return array<int, string>
     */
    private static function paths(array $values, string $prefix = ''): array
    {
        $out = [];

        foreach ($values as $key => $value) {
            $path = $prefix === '' ? (string) $key : $prefix . '.' . $key;

            if (is_array($value)) {
                $out = array_merge($out, self::paths($value, $path));

                continue;
            }

            $out[] = $path;
        }

        return $out;
    }
}
